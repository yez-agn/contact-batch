# ContactBatch

Application Android native (Java) pour importer une liste de numéros dans les contacts.

## Fonctionnement
- Un numéro par ligne (les virgules et points-virgules sont aussi acceptés).
- Préfixe de nom, par exemple `GROUPE` => `GROUPE 001`, `GROUPE 002`, etc.
- Demande les permissions Android READ_CONTACTS et WRITE_CONTACTS.
- Ignore les doublons dans la liste et les numéros déjà présents selon la comparaison Android.
- Pas de permission Internet et pas de serveur requis pour l'application.

## Compiler
Projet Gradle Android, JDK 17, Android SDK 35, Gradle 8.9.
Une GitHub Actions workflow est fourni dans `.github/workflows/build-apk.yml` pour compiler l'APK de débogage et publier l'APK comme artifact.

Note: la façon dont les contacts sont stockés (compte local, compte synchronisé par défaut ou comportement du fabricant) peut varier selon le fournisseur de contacts du téléphone. Testez d'abord avec quelques numéros fictifs.
