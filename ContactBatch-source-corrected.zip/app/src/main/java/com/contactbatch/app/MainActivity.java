package com.contactbatch.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.PhoneNumberUtils;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQUEST_CONTACTS = 44;
    private EditText prefixInput;
    private EditText numbersInput;
    private TextView status;
    private Button saveButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        int pad = dp(18);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("ContactBatch");
        title.setTextSize(28);
        title.setTextColor(0xFF17324D);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView intro = new TextView(this);
        intro.setText("Ajoute plusieurs numéros au répertoire en une seule opération. Un numéro par ligne.");
        intro.setTextSize(15);
        intro.setPadding(0, dp(8), 0, dp(18));
        root.addView(intro);

        TextView prefixLabel = new TextView(this);
        prefixLabel.setText("Nom de base");
        prefixLabel.setTextSize(16);
        root.addView(prefixLabel);
        prefixInput = new EditText(this);
        prefixInput.setSingleLine(true);
        prefixInput.setText("GROUPE");
        prefixInput.setHint("Ex. GROUPE");
        root.addView(prefixInput, new LinearLayout.LayoutParams(-1, -2));

        TextView numbersLabel = new TextView(this);
        numbersLabel.setText("Numéros de téléphone");
        numbersLabel.setTextSize(16);
        numbersLabel.setPadding(0, dp(16), 0, dp(4));
        root.addView(numbersLabel);
        numbersInput = new EditText(this);
        numbersInput.setGravity( android.view.Gravity.TOP | android.view.Gravity.START );
        numbersInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        numbersInput.setSingleLine(false);
        numbersInput.setMinLines(8);
        numbersInput.setHint("229XXXXXXXX\n229XXXXXXXX\n229XXXXXXXX");
        numbersInput.setPadding(dp(10), dp(10), dp(10), dp(10));
        root.addView(numbersInput, new LinearLayout.LayoutParams(-1, dp(220)));

        saveButton = new Button(this);
        saveButton.setText("ENREGISTRER LES CONTACTS");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(16);
        root.addView(saveButton, bp);
        saveButton.setOnClickListener(v -> onSavePressed());

        status = new TextView(this);
        status.setText("Prêt. Les doublons déjà présents seront ignorés.");
        status.setTextSize(14);
        status.setPadding(0, dp(14), 0, 0);
        root.addView(status);

        TextView note = new TextView(this);
        note.setText("Conseil : colle un numéro par ligne. Les contacts sont créés dans le répertoire du téléphone. Vérifie les résultats dans Contacts après l'importation.");
        note.setTextSize(13);
        note.setPadding(0, dp(18), 0, 0);
        root.addView(note);
        setContentView(scroll);
    }

    private void onSavePressed() {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS}, REQUEST_CONTACTS);
            return;
        }
        importContacts();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CONTACTS) {
            boolean granted = grantResults.length >= 2;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            if (granted) importContacts();
            else status.setText("Autorisation refusée. Autorise la lecture et l'ajout de contacts dans les paramètres Android.");
        }
    }

    private void importContacts() {
        String prefix = prefixInput.getText().toString().trim();
        if (prefix.isEmpty()) { prefixInput.setError("Entre un nom de base"); return; }
        String raw = numbersInput.getText().toString();
        String[] lines = raw.split("[\\r\\n,;]+", -1);
        List<String> numbers = new ArrayList<>();
        Set<String> inputKeys = new HashSet<>();
        int invalid = 0, repeatedInPaste = 0;
        for (String line : lines) {
            String number = line.trim();
            if (number.isEmpty()) continue;
            number = number.replaceAll("[\\s()\\-]", "");
            if (!number.matches("\\+?[0-9]{5,20}")) { invalid++; continue; }
            String key = digits(number);
            if (!inputKeys.add(key)) { repeatedInPaste++; continue; }
            numbers.add(number);
        }
        if (numbers.isEmpty()) {
            status.setText("Aucun numéro valide trouvé. Colle un numéro par ligne.");
            return;
        }
        saveButton.setEnabled(false);
        status.setText("Vérification des numéros et enregistrement en cours…");
        final int bad = invalid;
        final int repeated = repeatedInPaste;
        new Thread(() -> {
            int added = 0, existing = 0, errors = 0;
            try {
                Set<String> existingNumbers = loadExistingNumbers();
                List<String> toAdd = new ArrayList<>();
                for (String n : numbers) {
                    if (isDuplicate(n, existingNumbers)) existing++;
                    else {
                        toAdd.add(n);
                        existingNumbers.add(digits(n));
                    }
                }
                int sequence = 1;
                // Keep groups below the provider's usual batch-operation limits.
                for (int start = 0; start < toAdd.size(); start += 100) {
                    int end = Math.min(start + 100, toAdd.size());
                    ArrayList<ContentProviderOperation> ops = new ArrayList<>();
                    for (int i = start; i < end; i++) {
                        String number = toAdd.get(i);
                        String displayName = prefix + " " + String.format(Locale.ROOT, "%03d", sequence++);
                        int rawIndex = ops.size();
                        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build());
                        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, rawIndex)
                            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                            .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, displayName).build());
                        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, rawIndex)
                            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                            .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, number)
                            .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE).build());
                    }
                    try {
                        getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
                        added += end - start;
                    } catch (Exception batchError) {
                        // Retry one contact at a time so a single provider error doesn't lose the entire batch.
                        for (int i = start; i < end; i++) {
                            String number = toAdd.get(i);
                            String name = prefix + " " + String.format(Locale.ROOT, "%03d", sequence - (end - start) + (i - start));
                            try { insertOne(name, number); added++; }
                            catch (Exception e) { errors++; }
                        }
                    }
                }
            } catch (Exception e) { errors += numbers.size(); }
            final int a = added, d = existing, e = errors;
            runOnUiThread(() -> {
                saveButton.setEnabled(true);
                status.setText("Terminé. Ajoutés : " + a + "\nDéjà présents/ignorés : " + d + "\nRépétés dans la liste : " + repeated + "\nLignes invalides : " + bad + "\nÉchecs : " + e);
                Toast.makeText(this, "Importation terminée : " + a + " contact(s) ajouté(s)", Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private Set<String> loadExistingNumbers() {
        Set<String> values = new HashSet<>();
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        try (Cursor c = getContentResolver().query(uri, new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null)) {
            if (c != null) while (c.moveToNext()) {
                String n = c.getString(0);
                if (n != null) values.add(digits(n));
            }
        }
        return values;
    }

    private boolean isDuplicate(String number, Set<String> existing) {
        String key = digits(number);
        if (existing.contains(key)) return true;
        // Also compare international/local representations where Android can recognize them.
        for (String old : existing) {
            if (old.length() >= 7 && key.length() >= 7 && PhoneNumberUtils.compare(old, key)) return true;
        }
        return false;
    }

    private String digits(String s) { return s.replaceAll("[^0-9]", ""); }

    private void insertOne(String name, String number) throws Exception {
        ContentResolver resolver = getContentResolver();
        ContentValues raw = new ContentValues();
        Uri rawUri = resolver.insert(ContactsContract.RawContacts.CONTENT_URI, raw);
        if (rawUri == null) throw new Exception("Création du contact impossible");
        long rawId = ContentUris.parseId(rawUri);
        ContentValues nm = new ContentValues();
        nm.put(ContactsContract.Data.RAW_CONTACT_ID, rawId);
        nm.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE);
        nm.put(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name);
        resolver.insert(ContactsContract.Data.CONTENT_URI, nm);
        ContentValues ph = new ContentValues();
        ph.put(ContactsContract.Data.RAW_CONTACT_ID, rawId);
        ph.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
        ph.put(ContactsContract.CommonDataKinds.Phone.NUMBER, number);
        ph.put(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE);
        resolver.insert(ContactsContract.Data.CONTENT_URI, ph);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
